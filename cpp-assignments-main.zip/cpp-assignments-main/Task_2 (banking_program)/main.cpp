/*#include <iostream>
#include <algorithm>
#include "banking.h"
#include "account.h"
using namespace std;

int main()
{
     banking obj;
    obj.addAccount("sanju","3715",9000);
    obj.addAccount("annu","3716",18000);
    obj.addAccount("nagu","4569",50000);
    obj.removeAccountByid("3715");

    cout << obj.FindAccountById("3716") << "\n";
    cout << obj.FindAccountsWithCustomerName("nagu") << "\n";
    cout << obj.AvgBalance() << "\n";
    cout << "No.of Counts Accounts Within Range=" << obj.CountAccountsWithInRange(1000,200000) << "\n";
    cout << "No.of Accounts less than limit=" << obj.CountAccountsLessThanLimit(60000) << "\n";
    obj.AccountWithMaxBal();
    return 0;
}*/
